#include "Examen.h"

Examen::Examen(QWidget *parent)
	: QMainWindow(parent)
{
	ui.setupUi(this);
}
